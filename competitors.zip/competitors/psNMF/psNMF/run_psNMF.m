close all;
clc;
clear all;

addpath('./');

% 设置
n_runs = 10;

% 初始化结果存储
results.acc = zeros(n_runs, 1);
results.nmi = zeros(n_runs, 1);
results.purity = zeros(n_runs, 1);
results.psnmf_time = zeros(n_runs, 1);  % PSNMF时间
results.kmeans_time = zeros(n_runs, 1); % K-means时间
results.total_time = zeros(n_runs, 1);  % 总时间

fprintf('Processing dataset with True PSNMF: %d runs\n', n_runs);

for run = 1:n_runs
    fprintf('\nRun %d/%d\n', run, n_runs);

        % 数据加载
        [X, Y_true, c] = load_dataset('seeds_dataset.csv');

        fprintf('成功加载数据\n');
        fprintf('特征矩阵X大小: %dx%d\n', size(X,1), size(X,2));
        fprintf('发现 %d 个类别\n', c);
        fprintf('标签向量Y_true大小: %dx%d\n', size(Y_true,1), size(Y_true,2));

        % 数据清洗
        nan_mask = any(isnan(X), 2) | isnan(Y_true);
        if sum(nan_mask) > 0
            X = X(~nan_mask, :);
            Y_true = Y_true(~nan_mask);
            fprintf('清洗后数据大小: %dx%d\n', size(X,1), size(X,2));
        else
            fprintf('没有发现NaN值\n');
        end

        % 特征预处理
        X = zscore(X);

        % 转置：psNMF
        X_psnmf = X';

        c = length(unique(Y_true));
        rank_val = c;

        fprintf('PSNMF输入: X_t=%dx%d, rank=%d\n', size(X_psnmf,1), size(X_psnmf,2), rank_val);

        % PSNMF调用
        psnmf_start = tic;

        max_iter = 200;
        tol = 1e-6;

        [W, H, converged, recon_error] = psNMF(X_psnmf, rank_val, max_iter, tol);

        results.psnmf_time(run) = toc(psnmf_start);

        fprintf('PSNMF完成 - W:%dx%d, H:%dx%d, 运行时间: %.4fs\n', ...
                size(W,1), size(W,2), size(H,1), size(H,2), results.psnmf_time(run));

        % 聚类
        % 使用丰度矩阵H的转置进行聚类
        % H: (rank x n_samples), 转置后: (n_samples x rank)
        cluster_data = H';

        % 计算K-means聚类时间
        kmeans_start = tic;
        labelnew = kmeans(cluster_data, c, 'Replicates', 10, 'MaxIter', 200, 'Display', 'final');
        results.kmeans_time(run) = toc(kmeans_start);

        % 计算总时间
        results.total_time(run) = results.psnmf_time(run) + results.kmeans_time(run);

        % 计算聚类指标
        metrics = ClusteringMeasure(Y_true, labelnew);

        results.acc(run) = metrics(1);
        results.nmi(run) = metrics(2);
        results.purity(run) = metrics(3);

        fprintf('聚类结果: ACC=%.4f, NMI=%.4f, Purity=%.4f, K-means时间: %.4fs\n', ...
                metrics(1), metrics(2), metrics(3), results.kmeans_time(run));

        results.total_time(run) = results.psnmf_time(run) + results.kmeans_time(run);
    end

% 结果统计

success_mask = results.acc > 0;
n_success = sum(success_mask);

if n_success > 0
    fprintf('\n综合统计结果 (基于%d次成功运行):\n', n_success);
    fprintf('%-10s %10s %10s %10s %10s\n', 'Metric', 'Mean', 'Max', 'Min', 'Std');
    fprintf('---------- ---------- ---------- ---------- ----------\n');

    metrics_names = {'ACC', 'NMI', 'Purity', 'Time(s)'};
    metrics_data = {results.acc, results.nmi, results.purity, results.total_time};

    for i = 1:length(metrics_names)
        data = metrics_data{i}(success_mask);
        fprintf('%-10s %10.4f %10.4f %10.4f %10.4f\n', ...
                metrics_names{i}, mean(data), max(data), min(data), std(data));
    end

else
    fprintf('没有成功的运行\n');
end

fprintf('成功运行次数: %d/%d\n', n_success, n_runs);
