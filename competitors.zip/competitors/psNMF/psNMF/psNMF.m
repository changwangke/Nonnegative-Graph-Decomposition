function [W, H, converged, recon_error] = psNMF(Y, rank, max_iter, tol)
    % PSNMF algorithm implementation
    % Parameter validation
    if nargin < 2
        error('At least 2 input arguments required: Y, rank');
    end

    if nargin < 3
        max_iter = 200;
    end

    if nargin < 4
        tol = 1e-6;
    end

    [n_features, n_samples] = size(Y);
    fprintf('True PSNMF: Y=%dx%d, rank=%d\n', n_features, n_samples, rank);

    % Check if PCA is needed
    if n_features <= rank
        fprintf('Features(%d) <= rank(%d), skipping PCA\n', n_features, rank);
        Ys = Y;
        coeff = eye(n_features);
        sub_dim = n_features;
    else
        % Center data
        Y_mean = mean(Y, 2);
        Y_centered = Y - Y_mean;

        % Perform PCA using SVD
        [U, S, V] = svd(Y_centered, 'econ');
        explained = diag(S).^2 / sum(diag(S).^2) * 100;
        cum_var = cumsum(explained);

        % Determine subspace dimension (keep 95% variance)
        sub_dim = find(cum_var >= 95, 1);
        if isempty(sub_dim)
            sub_dim = min(rank + 10, n_features);
        end
        sub_dim = max(sub_dim, rank); % Ensure subspace dimension >= rank

        sub_dim = min(sub_dim, n_features); % Ensure within bounds

        fprintf('Selected subspace dimension: %d (%.1f%% variance)\n', sub_dim, cum_var(min(sub_dim, length(cum_var))));

        % Subspace data
        Ys = S(1:sub_dim, 1:sub_dim) * V(:, 1:sub_dim)';
        coeff = U(:, 1:sub_dim);
    end


    % Initialize using SVD
    [U_svd, S_svd, V_svd] = svds(Ys, rank);

    Ws = abs(U_svd * sqrt(S_svd)) + 1e-6;
    Hs = abs(sqrt(S_svd) * V_svd') + 1e-6;

    avoid_zero = 1e-12;
    best_error = inf;
    best_Ws = Ws;
    best_Hs = Hs;
    converged = false;
    recon_error = zeros(max_iter, 1);

    for iter = 1:max_iter
        try
            % Update abundance matrix Hs
            Hs = Hs .* (Ws' * Ys) ./ (Ws' * Ws * Hs + avoid_zero);
            Hs = max(Hs, avoid_zero);

            % Update endmember matrix Ws
            Ws = Ws .* (Ys * Hs') ./ (Ws * (Hs * Hs') + avoid_zero);
            Ws = max(Ws, avoid_zero);

            % Calculate reconstruction error
            current_error = norm(Ys - Ws * Hs, 'fro')^2;
            recon_error(iter) = current_error;

            % Save best results
            if current_error < best_error
                best_error = current_error;
                best_Ws = Ws;
                best_Hs = Hs;
            end

            % Check convergence
            if iter > 1
                rel_change = abs(recon_error(iter-1) - current_error) / (recon_error(iter-1) + avoid_zero);
                if rel_change < tol
                    converged = true;
                    break;
                end
            end

            if mod(iter, 50) == 0
                fprintf('Iteration %3d - Error: %.6f\n', iter, current_error);
            end

        catch ME
            fprintf('Iteration %d failed: %s\n', iter, ME.message);
            break;
        end
    end

    % Use best subspace results
    Ws = best_Ws;
    Hs = best_Hs;

    if n_features > rank
        % Project back: W = coeff * Ws
        W = coeff(:, 1:sub_dim) * Ws;
    else
        W = Ws;
    end

    % Ensure non-negativity
    W = max(W, 0);

    % Abundance matrix is Hs from subspace
    H = Hs;

    % Calculate final reconstruction error (in original space)
    final_error = norm(Y - W * H, 'fro')^2;

end

