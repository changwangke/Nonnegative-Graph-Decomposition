%% 诊断 symnmf_cluster 内部问题
clear; clc;

% 加载数据
[X_data, trueLabels, K] = load_dataset('COIL20.mat');
fprintf('数据矩阵大小: %dx%d\n', size(X_data));

% 手动构建相似度矩阵（与 symnmf_cluster 中相同的流程）
fprintf('\n手动重现 symnmf_cluster 的相似度构建流程...\n');

% 步骤1: 计算距离矩阵
D = dist2(X_data, X_data);
fprintf('1. 距离矩阵大小: %dx%d\n', size(D));

% 步骤2: 构建稀疏高斯相似度矩阵
graph_type = 'sparse';
similarity_type = 'gaussian';
nn_val = 7;
kk_val = floor(log2(size(X_data, 1))) + 1;

if strcmp(graph_type, 'sparse') && strcmp(similarity_type, 'gaussian')
    A = scale_dist3_knn(D, nn_val, kk_val, true);
    fprintf('2. 稀疏高斯相似度矩阵大小: %dx%d, 非零元素: %d\n', size(A), nnz(A));
end

% 步骤3: 归一化处理
graph_objfun = 'ncut';
if strcmp(graph_objfun, 'ncut')
    dd = 1 ./ sum(A);
    dd = sqrt(dd);
    A = bsxfun(@times, A, dd);
    A = A';
    A = bsxfun(@times, A, dd);
    clear dd;
end
A = (A + A') / 2;
fprintf('3. 归一化后相似度矩阵大小: %dx%d\n', size(A));

% 步骤4: 调用 symnmf_anls 进行测试
fprintf('\n测试直接调用 symnmf_anls...\n');
params.maxiter = 10;
params.tol = 1e-3;
params.alpha = max(max(A))^2;
params.computeobj = true;

try
    [H_anls, iter_anls, obj_anls] = symnmf_anls(A, K, params);
    fprintf('✓ symnmf_anls 调用成功\n');
    fprintf('  H矩阵大小: %dx%d\n', size(H_anls));
    fprintf('  迭代次数: %d\n', iter_anls);
    fprintf('  目标函数值: %.6f\n', obj_anls);
    
    % 聚类分配
    [~, predLabels] = max(H_anls, [], 2);
    metrics = ClusteringMeasure(predLabels, trueLabels);
    fprintf('  聚类结果: ACC=%.2f%%, NMI=%.2f%%, Purity=%.2f%%\n', ...
        metrics(1)*100, metrics(2)*100, metrics(3)*100);
    
catch ME
    fprintf('❌ symnmf_anls 调用失败: %s\n', ME.message);
    fprintf('错误堆栈:\n');
    for i = 1:length(ME.stack)
        fprintf('  文件: %s, 函数: %s, 行: %d\n', ...
            ME.stack(i).file, ME.stack(i).name, ME.stack(i).line);
    end
end