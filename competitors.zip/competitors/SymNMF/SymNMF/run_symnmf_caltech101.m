clc
clear all

%% 数据加载部分
[X_data, trueLabels, K] = load_dataset('caltech101_resnet18_features_10classes.csv');
X_data = zscore(X_data);

load('caltech101.mat'); % 读取邻接矩阵
W = max(W, W'); % 确保对称
W = W - diag(diag(W)); % 对角线置零

% % 1. 构建相似度矩阵
% fprintf('构建相似度矩阵...\n');
% k = 25;
% W = construct_similarity_matrix2(X_data, k);
% W = max(W, W'); % 确保对称
% W = W - diag(diag(W)); % 对角线置零


%% 实验参数设置
numRuns = 5;  
fprintf('运行次数: %d\n', numRuns);

%% 初始化结果存储
acc_results = zeros(numRuns, 1);
nmi_results = zeros(numRuns, 1);
purity_results = zeros(numRuns, 1);
time_results = zeros(numRuns, 1);
iter_results = zeros(numRuns, 1);
obj_results = zeros(numRuns, 1);

%% 多次运行聚类实验
fprintf('\n开始运行聚类实验...\n');
fprintf('Run#    ACC(%%)    NMI(%%)   Purity(%%)   Time(s)   Iter\n');
fprintf('----   --------   --------   --------   --------   ----\n');

for run = 1:numRuns
    fprintf('%4d', run);
    
    % 计时开始
    t_start = tic;
    
    try
        % 调用 SymNMF 进行聚类
        [H, iter, obj] = symnmf_newton(W, K);  
        [max_val, idx] = max(H, [], 2);
        
        % 计算运行时间
        runtime = toc(t_start);
        
        % 计算聚类评估指标
        metrics = ClusteringMeasure(idx, trueLabels);
        
        % 存储结果
        acc_results(run) = metrics(1);
        nmi_results(run) = metrics(2);
        purity_results(run) = metrics(3);
        time_results(run) = runtime;
        iter_results(run) = iter;
        obj_results(run) = obj;
        
        fprintf('   %8.2f   %8.2f   %8.2f   %8.4f   %4d\n', ...
            acc_results(run)*100, nmi_results(run)*100, ...
            purity_results(run)*100, runtime, iter);
        
    catch ME
        runtime = toc(t_start);
        fprintf('   运行失败: %s\n', ME.message);
        acc_results(run) = 0;
        nmi_results(run) = 0;
        purity_results(run) = 0;
        time_results(run) = runtime;
        iter_results(run) = 0;
        obj_results(run) = -1;
    end
end

%% 结果统计与分析
fprintf('\n');
fprintf('SYMNMF 聚类实验最终统计结果\n');

% 筛选成功的运行
success_mask = acc_results > 0;
n_success = sum(success_mask);

if n_success > 0
    fprintf('综合统计结果 (基于%d次成功运行):\n', n_success);
    fprintf('%-12s %10s %10s %10s %10s\n', 'Metric', 'Mean', 'Max', 'Min', 'Std');
    fprintf('------------ ---------- ---------- ---------- ----------\n');
    
    % ACC 统计
    acc_data = acc_results(success_mask);
    meanACC = mean(acc_data);
    maxACC = max(acc_data);
    minACC = min(acc_data);
    stdACC = std(acc_data);
    fprintf('%-12s %10.4f %10.4f %10.4f %10.4f\n', ...
            'ACC', meanACC, maxACC, minACC, stdACC);
    
    % NMI 统计
    nmi_data = nmi_results(success_mask);
    meanNMI = mean(nmi_data);
    maxNMI = max(nmi_data);
    minNMI = min(nmi_data);
    stdNMI = std(nmi_data);
    fprintf('%-12s %10.4f %10.4f %10.4f %10.4f\n', ...
            'NMI', meanNMI, maxNMI, minNMI, stdNMI);
    
    % Purity 统计
    purity_data = purity_results(success_mask);
    meanPurity = mean(purity_data);
    maxPurity = max(purity_data);
    minPurity = min(purity_data);
    stdPurity = std(purity_data);
    fprintf('%-12s %10.4f %10.4f %10.4f %10.4f\n', ...
            'Purity', meanPurity, maxPurity, minPurity, stdPurity);
    
    % 时间统计
    time_data = time_results(success_mask);
    meanTime = mean(time_data);
    maxTime = max(time_data);
    minTime = min(time_data);
    stdTime = std(time_data);
    fprintf('%-12s %10.4f %10.4f %10.4f %10.4f\n', ...
            'Time(s)', meanTime, maxTime, minTime, stdTime);
    
    % 迭代次数统计
    iter_data = iter_results(success_mask);
    meanIter = mean(iter_data);
    maxIter = max(iter_data);
    minIter = min(iter_data);
    stdIter = std(iter_data);
    fprintf('%-12s %10.4f %10.4f %10.4f %10.4f\n', ...
            'Iterations', meanIter, maxIter, minIter, stdIter);
    
    % 目标函数值统计
    if any(obj_results(success_mask) ~= -1)
        obj_data = obj_results(success_mask & obj_results ~= -1);
        if ~isempty(obj_data)
            meanObj = mean(obj_data);
            maxObj = max(obj_data);
            minObj = min(obj_data);
            stdObj = std(obj_data);
            fprintf('%-12s %10.4f %10.4f %10.4f %10.4f\n', ...
                    'Objective', meanObj, maxObj, minObj, stdObj);
        end
    end

else
    fprintf(' 没有成功的运行\n');
    % 初始化统计变量，避免后续错误
    meanACC = 0; maxACC = 0; stdACC = 0;
    meanNMI = 0; maxNMI = 0; stdNMI = 0;
    meanPurity = 0; maxPurity = 0; stdPurity = 0;
    meanTime = 0; minTime = 0; stdTime = 0;
end

fprintf('\n成功率: %d/%d (%.1f%%)\n', n_success, numRuns, n_success/numRuns*100);

%% 将结果记录到 Excel 文件中
fprintf('\n--- 正在将结果写入 Excel 文件... ---\n');

% --- 参数配置 ---
excel_filename = 'data_GCC_Xiong+Qiu+Chen.xlsx';
algorithm_name = 'symNMF';
target_col = 7; 

% --- 准备写入的字符串数据 ---
acc_str = sprintf('%.2f%%(%.2f%%)(%.2f%%)', meanACC * 100, maxACC * 100, stdACC * 100);
nmi_str = sprintf('%.2f%%(%.2f%%)(%.2f%%)', meanNMI * 100, maxNMI * 100, stdNMI * 100);
purity_str = sprintf('%.2f%%(%.2f%%)(%.2f%%)', meanPurity * 100, maxPurity * 100, stdPurity * 100);
time_str = sprintf('%.4fs(%.4fs)(%.4fs)', meanTime, minTime, stdTime);

% --- 写入数据到 Excel ---
try
    try
        ref_col_a = readcell(excel_filename, 'Sheet', 'ACC', 'Range', 'A:A');
        row_idx = find(strcmp(ref_col_a, algorithm_name));
        if isempty(row_idx)
            target_row = size(ref_col_a, 1) + 1;
            fprintf('在A列未找到算法名称 "%s"，将追加到新的第 %d 行。\n', algorithm_name, target_row);
        else
            target_row = row_idx(1);
            fprintf('成功找到算法名称 "%s" 在第 %d 行。\n', algorithm_name, target_row);
        end
    catch read_err
        fprintf('无法读取参考工作表来定位行号(错误: %s)。\n', read_err.message);
        target_row = 15; % 提供一个备用行号
        fprintf('将使用备用行号: %d。\n', target_row);
    end

    target_col_letter = char('A' + target_col - 1);
    
    write_to_excel = @(sheet_name, data_cell) ...
        writecell(data_cell, excel_filename, 'Sheet', sheet_name, 'Range', [target_col_letter num2str(target_row)]);
    
    write_algo_name = @(sheet_name) ...
        writecell({algorithm_name}, excel_filename, 'Sheet', sheet_name, 'Range', ['A' num2str(target_row)]);

    % 写入性能指标和原始TIME
    write_algo_name('ACC');    write_to_excel('ACC', {acc_str});
    write_algo_name('Purity'); write_to_excel('Purity', {purity_str});
    write_algo_name('NMI');    write_to_excel('NMI', {nmi_str});
    write_algo_name('TIME');   write_to_excel('TIME', {time_str});
    
    fprintf('结果成功写入到文件 "%s" 的第 %d 行。\n', excel_filename, target_row);

catch ME
    fprintf('\n错误: 无法写入到 Excel 文件 "%s"。\n', excel_filename);
    fprintf('请确保:\n');
    fprintf('1. 文件没有被其他程序打开，且已保存。\n');
    fprintf('2. 您有写入该文件的权限。\n');
    fprintf('3. 所有需要的工作表 (ACC, Purity, NMI, TIME等) 已存在。\n');
    fprintf('错误信息: %s\n', ME.message);
end